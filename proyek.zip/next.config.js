/** Situs statis: semua halaman berjalan di browser, data diambil langsung dari Supabase. */
module.exports = {
  output: 'export',
  trailingSlash: true,
  images: { unoptimized: true },
};
