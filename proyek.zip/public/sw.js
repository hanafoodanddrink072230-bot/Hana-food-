// Service worker minimal: membuat aplikasi bisa di-install.
// Data keuangan sengaja TIDAK disimpan di cache agar angka selalu terbaru.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
