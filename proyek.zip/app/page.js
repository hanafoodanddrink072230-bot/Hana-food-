'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../lib/supabase';

const rupiah = (n) =>
  new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n || 0);

const NAMA_PERAN = { owner: 'Pemilik', admin: 'Admin', finance: 'Finance', kasir: 'Kasir' };

function Bingkai({ children }) {
  return <main className="mx-auto min-h-screen max-w-md px-4 pb-10 pt-5">{children}</main>;
}

export default function Beranda() {
  const router = useRouter();
  const [state, setState] = useState({ status: 'memuat' });

  useEffect(() => {
    let batal = false;
    async function muat() {
      if (!supabase) {
        setState({ status: 'konfigurasi' });
        return;
      }
      const { data: sesi } = await supabase.auth.getSession();
      if (!sesi.session) {
        router.replace('/login/');
        return;
      }
      const { data: profil, error } = await supabase
        .from('profiles')
        .select('nama, peran, aktif')
        .eq('id', sesi.session.user.id)
        .single();
      if (error || !profil) {
        if (!batal) setState({ status: 'galat' });
        return;
      }
      if (!profil.aktif) {
        if (!batal) setState({ status: 'nonaktif', profil });
        return;
      }
      let akun = null;
      if (profil.peran === 'owner' || profil.peran === 'finance') {
        const { data } = await supabase
          .from('v_saldo_akun')
          .select('kode, nama, saldo')
          .eq('is_kas_bank', true)
          .order('kode');
        akun = data || [];
      }
      if (!batal) setState({ status: 'siap', profil, akun });
    }
    muat();
    return () => {
      batal = true;
    };
  }, [router]);

  async function keluar() {
    if (supabase) await supabase.auth.signOut();
    router.replace('/login/');
  }

  const tombolKeluar = (
    <button onClick={keluar} className="mt-6 min-h-[44px] w-full rounded-xl border border-[#1F3F5B] text-[15px] font-semibold text-[#1F3F5B]">
      Keluar
    </button>
  );

  if (state.status === 'memuat') {
    return <Bingkai><p className="mt-20 text-center text-sm text-[#5B6B7A]">Memuat...</p></Bingkai>;
  }
  if (state.status === 'konfigurasi') {
    return (
      <Bingkai>
        <p className="mt-20 text-center text-sm text-[#9C2F1F]">
          Aplikasi belum terhubung ke database. Isi pengaturan hosting lalu bangun ulang.
        </p>
      </Bingkai>
    );
  }
  if (state.status === 'galat') {
    return (
      <Bingkai>
        <p className="mt-20 text-center text-sm text-[#9C2F1F]">Profil tidak ditemukan. Hubungi pemilik.</p>
        {tombolKeluar}
      </Bingkai>
    );
  }
  if (state.status === 'nonaktif') {
    return (
      <Bingkai>
        <h1 className="mt-16 text-center text-lg font-bold text-[#1F3F5B]">Akun belum aktif</h1>
        <p className="mt-2 text-center text-sm text-[#5B6B7A]">Minta pemilik untuk mengaktifkan akunmu.</p>
        {tombolKeluar}
      </Bingkai>
    );
  }

  const { profil, akun } = state;
  const total = (akun || []).reduce((jumlah, a) => jumlah + Number(a.saldo || 0), 0);
  const inisial = (profil.nama || '?').trim().charAt(0).toUpperCase();

  return (
    <Bingkai>
      <header className="flex items-center justify-between">
        <div>
          <div className="text-lg font-bold text-[#1F3F5B]">HANA Food &amp; Drinks</div>
          <div className="text-xs text-[#5B6B7A]">{profil.nama} · {NAMA_PERAN[profil.peran]}</div>
        </div>
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#1F3F5B] font-semibold text-white">
          {inisial}
        </div>
      </header>

      {akun ? (
        <section className="mt-5 rounded-[18px] bg-[#1F3F5B] p-4 text-white">
          <div className="text-xs text-[#C9D6E2]">Total saldo</div>
          <div className="mb-3 mt-0.5 text-[30px] font-bold">{rupiah(total)}</div>
          <div className="grid grid-cols-2 gap-x-3 gap-y-3 text-xs">
            {akun.map((a) => (
              <div key={a.kode}>
                <div className="text-[#C9D6E2]">{a.nama}</div>
                <div className="text-sm font-semibold">{rupiah(a.saldo)}</div>
              </div>
            ))}
          </div>
        </section>
      ) : (
        <section className="mt-5 rounded-[16px] bg-white p-4 shadow-sm">
          <p className="text-sm text-[#1B2733]">Halaman untuk peran {NAMA_PERAN[profil.peran]} segera hadir.</p>
        </section>
      )}

      {tombolKeluar}
    </Bingkai>
  );
}
