import './globals.css';
import RegistrasiSW from '../components/RegistrasiSW';

export const metadata = {
  title: 'HANA Keuangan',
  description: 'Pembukuan HANA Food & Drinks',
  manifest: '/manifest.webmanifest',
  icons: { icon: '/icon-192.png', apple: '/icon-192.png' },
  appleWebApp: { capable: true, title: 'HANA Keuangan' },
};

export const viewport = {
  themeColor: '#1F3F5B',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>
        {children}
        <RegistrasiSW />
      </body>
    </html>
  );
}
