'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../../lib/supabase';

export default function Masuk() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [sandi, setSandi] = useState('');
  const [pesan, setPesan] = useState('');
  const [proses, setProses] = useState(false);

  async function kirim(e) {
    e.preventDefault();
    setPesan('');
    if (!supabase) {
      setPesan('Aplikasi belum terhubung ke database. Hubungi pemilik.');
      return;
    }
    setProses(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: sandi });
    setProses(false);
    if (error) {
      setPesan('Email atau kata sandi salah.');
      return;
    }
    router.replace('/');
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6 py-10">
      <div className="mx-auto flex h-[72px] w-[72px] items-center justify-center rounded-[20px] bg-[#1F3F5B] text-[34px] font-bold text-white">
        H
      </div>
      <h1 className="mt-4 text-center text-[22px] font-bold text-[#1F3F5B]">HANA Food &amp; Drinks</h1>
      <p className="mt-1 text-center text-sm text-[#5B6B7A]">Masuk untuk mencatat keuangan</p>

      <form onSubmit={kirim} className="mt-8">
        <label htmlFor="email" className="mb-1 block text-xs text-[#5B6B7A]">Email</label>
        <input
          id="email" type="email" required autoComplete="username"
          value={email} onChange={(e) => setEmail(e.target.value)}
          className="h-12 w-full rounded-xl border border-[#C3CED9] bg-white px-3 text-[15px]"
        />
        <label htmlFor="sandi" className="mb-1 mt-3 block text-xs text-[#5B6B7A]">Kata sandi</label>
        <input
          id="sandi" type="password" required autoComplete="current-password"
          value={sandi} onChange={(e) => setSandi(e.target.value)}
          className="h-12 w-full rounded-xl border border-[#C3CED9] bg-white px-3 text-[15px]"
        />
        {pesan && (
          <p role="alert" className="mt-3 rounded-lg bg-[#FDECE9] px-3 py-2 text-sm text-[#9C2F1F]">{pesan}</p>
        )}
        <button
          type="submit" disabled={proses}
          className="mt-5 h-[52px] w-full rounded-[14px] bg-[#1F3F5B] text-base font-semibold text-white disabled:opacity-60"
        >
          {proses ? 'Memeriksa...' : 'Masuk'}
        </button>
      </form>
      <p className="mt-10 text-center text-xs text-[#5B6B7A]">Satu orang satu akun. Jangan bagikan kata sandi.</p>
    </main>
  );
}
